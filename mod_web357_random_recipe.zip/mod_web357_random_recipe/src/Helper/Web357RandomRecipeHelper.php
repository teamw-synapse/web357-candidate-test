<?php
/**
 * @package     Com_Web357test
 * @subpackage  mod_web357_random_recipe
 * @author      Web357 Dev <careers@web357.com>
 * @copyright   2025 Web357.com
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Web357\Module\RandomRecipe\Helper;

use Joomla\CMS\Factory;
use Joomla\CMS\Application\SiteApplication;
use Joomla\Registry\Registry;
use Joomla\Database\DatabaseDriver;
use Joomla\DI\Container;
use Joomla\DI\ContainerAwareInterface;
use Joomla\DI\ContainerAwareTrait;

defined('_JEXEC') or die;

/**
 * Helper class for Web357 Random Recipe module.
 *
 * @since 5.1.0
 */
class Web357RandomRecipeHelper implements ContainerAwareInterface
{
    use ContainerAwareTrait;

    protected DatabaseDriver $db;
    protected SiteApplication $app;
    protected Registry $params;

    /**
     * Constructor for dependency injection.
     *
     * @param  DatabaseDriver   $db
     * @param  SiteApplication  $app
     * @param  Registry         $params
     */
    public function __construct(DatabaseDriver $db, SiteApplication $app, Registry $params)
    {
        $this->db = $db;
        $this->app = $app;
        $this->params = $params;
    }

    /**
     * Fetch a random recipe from the database.
     *
     * @return object|null
     */
    // public function getRandomRecipe(): ?object
    // {
    //     $query = $this->db->getQuery(true)
    //         ->select('*')
    //         ->from($this->db->quoteName('#__random_recipes'))
    //         ->order('RAND()')
    //         ->setLimit(1);

    //     return $this->db->setQuery($query)->loadObject();
    // }
}
