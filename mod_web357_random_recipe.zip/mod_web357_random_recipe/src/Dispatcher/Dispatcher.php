<?php
/**
 * @package     Com_Web357test
 * @subpackage  mod_web357_random_recipe
 * @author     Web357 Dev <careers@web357.com>
 * @copyright  2025 Web357.com
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;

class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;

    protected function getLayoutData()
    {
        $data = parent::getLayoutData();

        $data['msg'] = $this->getHelperFactory()->getHelper('Web357RandomRecipeHelper')->getData($data['params'], $this->getApplication());

        return $data;
    }
}