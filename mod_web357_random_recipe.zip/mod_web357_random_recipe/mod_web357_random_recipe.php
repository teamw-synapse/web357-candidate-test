<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Web357test
 * @subpackage mod_web357_random_recipe
 * @author     Web357 Dev <careers@web357.com>
 * @copyright  2025 Web357.com
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Language\Text;

require_once __DIR__ . '/helper.php';

// Fetch a random recipe from the database
$recipe = ModWeb357RandomRecipeHelper::getRandomRecipe();

$moduleClassSfx = htmlspecialchars($params->get('moduleclass_sfx', ''));

require ModuleHelper::getLayoutPath('mod_web357_random_recipe', $params->get('layout', 'default'));
