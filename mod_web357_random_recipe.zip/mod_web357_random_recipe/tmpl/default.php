<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Web357test
 * @author     Web357 Dev <careers@web357.com>
 * @copyright  2025 Web357.com
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use Joomla\CMS\Component\ComponentHelper;


$params = ComponentHelper::getParams('com_web357test');

// Get a specific parameter value
$serving_size = $params->get('serving_size');

if ($recipe) { ?>
    <div class="random-recipe">
    <div><a href="<?php echo Route::_('index.php?option=com_web357test&view=recipe&id='.(int) $recipe->id); ?>">
                            <?php echo $recipe->title; ?></a> &nbsp;
     <?php 
            $difficultyLevels1 = ["easy" => 1, "medium" => 2, "hard" => 3];
                    $stars = isset($difficultyLevels1[$recipe->difficulty]) ? $difficultyLevels1[$recipe->difficulty] : 0;

                    echo '<span class="hidden">' . htmlspecialchars($recipe->difficulty) . '</span>';

                    for ($i = 0; $i < $stars; $i++) {
                        echo '<i class="fa fa-star" aria-hidden="true" style="color: yellow;"></i>';
                    }



    ?>
    </div>
    <div> <?php echo $serving_size; ?></div>

<?php
} else {
    echo '<span>' . JText::_('MOD_WEB357_RANDOM_RECIPE_NO_RECIPE') . '</span>';
}
?>
